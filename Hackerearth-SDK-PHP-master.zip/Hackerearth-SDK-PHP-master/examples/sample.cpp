#include <iostream>
using namespace std;
int main(){
	int a,b;
	cin>>a>>b;
    cout<<"Hi! Vipin"<<endl;
    cout<<"Sum of "<<a<<" & "<<b<<" = "<<a+b;
    return 0;
}
