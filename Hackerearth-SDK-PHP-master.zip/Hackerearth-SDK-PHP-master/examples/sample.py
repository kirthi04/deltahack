print("Hello! Vipin");
print(input()+input())

