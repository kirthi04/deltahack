puts 'Hi viru'
#take two space seperated integer inputs
a=gets.chomp.split("\s")
puts a[0].to_i*a[1].to_i
